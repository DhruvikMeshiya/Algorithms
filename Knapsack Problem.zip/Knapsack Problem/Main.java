import java.lang.Math;
import java.util.Scanner;

public class Main {
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter how many objects : ");
        int size = sc.nextInt();
        int v[] = new int[size];
        int w[] = new int[size];

        for(int i=0;i<v.length;i++)
        {
            System.out.println("Enter value for "+i);
            v[i] = sc.nextInt();
        }
        for(int i=0;i<w.length;i++)
        {
            System.out.println("Enter weight for "+i);
            w[i] = sc.nextInt();
        }
        System.out.println("Enter capacity : ");
        int c = sc.nextInt();
        int table[][] = new int[w.length+1][c+1];
        for (int i = 0; i <= w.length; i++)
        {
            table[i][0] = 0;
        }
        for (int i = 0; i <=c; i++)
        {
            table[0][i]=0;
        }
        for (int i = 1; i < w.length; i++)
        {
            for (int j = 1; j < c+1; j++)
            {
                if (j<w[i])
                {
                    table[i][j] = table [i-1][j];
                }
                if (j>=w[i])
                {
                    table[i][j] = Math.max(table[i-1][j] , table[i-1][j-w[i]] + v[i] );
                }
            }
        }

        for (int i = 0; i < w.length; i++)
        {
            for (int j = 0; j <= c; j++)
            {
                System.out.print(table[i][j] + "\t");
            }
            System.out.println();
        }
    }
}